document.getElementById("id_username").placeholder = "Usuario"
document.getElementById("id_password1").placeholder = "Senha"
document.getElementById("id_password2").placeholder = "Redigite a senha"